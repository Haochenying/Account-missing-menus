This module adds all missing menu entries for **Account** module.

* Chart of Account Templates
* Account Types
* Account Tags
* Account Group
* Bank Statements
